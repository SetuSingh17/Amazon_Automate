package com.example.amdocs.Setu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SetuApplication {

	public static void main(String[] args) {
		SpringApplication.run(SetuApplication.class, args);
	}

}
